package ankhangbo.fabricloader;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 * Real-time startup monitor: every 10 seconds (-Dankhangbo.watchdog.seconds=N) it prints a COMPACT status of the threads that
 * matter (ServerMain / Server thread / workers that are not idle, plus any deadlock) to the console and appends it to
 * hang-dump.txt. It stops by itself as soon as the server is ticking (a thread is inside MinecraftServer.tickServer) or after
 * -Dankhangbo.watchdog.max dumps (default 360 = 1 hour). Opt-in: "watchdog.enabled": true in config/modloader.json (or -Dankhangbo.watchdog=true).
 */
public final class HangWatchdog {
	private static final int MAX_FRAMES = 14;

	private HangWatchdog() { }

	public static void start() {
		if (!"true".equalsIgnoreCase(System.getProperty("ankhangbo.watchdog"))) return; // default OFF, see config/modloader.json

		final long interval = Math.max(1L, Long.getLong("ankhangbo.watchdog.seconds", 10L));
		final int max = Integer.getInteger("ankhangbo.watchdog.max", 360);
		Thread t = new Thread(() -> {
			try {
				for (int n = 1; n <= max; n++) {
					Thread.sleep(interval * 1000L);
					if (dump(n, interval)) return; // server is ticking -> started fine
				}
			} catch (InterruptedException ignored) {
				// stop
			}
		}, "watchdog");
		t.setDaemon(true);
		t.start();
	}

	private static boolean isIdle(ThreadInfo ti) {
		StackTraceElement[] st = ti.getStackTrace();
		if (st.length == 0) return true;
		String top = st[0].getClassName() + "." + st[0].getMethodName();
		boolean parked = top.contains("Unsafe.park") || top.contains("Object.wait") || top.contains("Thread.sleep");
		if (!parked) return false;
		// parked inside a pool's "wait for work" loop = idle worker
		for (StackTraceElement e : st) {
			String m = e.getClassName() + "." + e.getMethodName();
			if (m.contains("ForkJoinPool.awaitWork") || m.contains("ThreadPoolExecutor.getTask") || m.contains("ReferenceQueue.remove")
					|| m.contains("AsyncAppenderEventDispatcher") || m.contains("Util$9.run") || m.contains("CleanerThread")) return true;
		}
		return false;
	}

	/** @return true when the server is already ticking (watchdog can stop) */
	private static boolean dump(int n, long interval) {
		ThreadMXBean mx = ManagementFactory.getThreadMXBean();
		ThreadInfo[] all = mx.dumpAllThreads(false, false, 80);
		boolean ticking = false;
		StringBuilder sb = new StringBuilder();
		sb.append("[WATCHDOG #").append(n).append(" +").append(n * interval).append("s ").append(java.time.LocalTime.now().withNano(0)).append("]\n");

		long[] dead = mx.findDeadlockedThreads();
		if (dead != null && dead.length > 0) {
			sb.append("  !!! DEADLOCK:\n");
			for (ThreadInfo ti : mx.getThreadInfo(dead, 40)) sb.append(ti);
		}

		int shown = 0;
		int idle = 0;

		for (ThreadInfo ti : all) {
			String name = ti.getThreadName();
			if (name.equals("watchdog")) continue;

			for (StackTraceElement e : ti.getStackTrace()) {
				if (e.getClassName().endsWith("MinecraftServer") && e.getMethodName().equals("tickServer")) ticking = true;
			}

			if (isIdle(ti) || name.startsWith("Reference Handler") || name.startsWith("Finalizer") || name.startsWith("Signal Dispatcher")
					|| name.startsWith("Common-Cleaner") || name.startsWith("Notification Thread") || name.equals("DestroyJavaVM")) {
				idle++;
				continue;
			}

			shown++;
			sb.append("  \"").append(name).append("\" ").append(ti.getThreadState());
			if (ti.getLockName() != null) sb.append(" on ").append(ti.getLockName());
			if (ti.getLockOwnerName() != null) sb.append(" owned by ").append(ti.getLockOwnerName());
			sb.append('\n');
			StackTraceElement[] st = ti.getStackTrace();
			for (int i = 0; i < Math.min(st.length, MAX_FRAMES); i++) sb.append("      at ").append(st[i]).append('\n');
			if (st.length > MAX_FRAMES) sb.append("      ... ").append(st.length - MAX_FRAMES).append(" more\n");
		}

		sb.append("  (").append(shown).append(" active thread(s) shown, ").append(idle).append(" idle hidden)");
		if (ticking) sb.append("  -> server is ticking, watchdog stops");
		sb.append('\n');

		System.err.print(sb);

		try {
			Path p = Paths.get("hang-dump.txt");
			Files.write(p, sb.toString().getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
		} catch (Throwable ignored) {
			// console copy is enough
		}

		return ticking;
	}
}
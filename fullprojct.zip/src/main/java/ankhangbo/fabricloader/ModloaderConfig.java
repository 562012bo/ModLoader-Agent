package ankhangbo.fabricloader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

import net.fabricmc.loader.impl.lib.gson.JsonReader;
import net.fabricmc.loader.impl.lib.gson.JsonToken;

/**
 * Central switchboard: {@code config/modloader.json} (created with defaults on first start).
 *
 * <p>Every switch is translated into the {@code -Dankhangbo.*} system property the rest of the agent already reads, so no
 * other class needs to know about the file. An explicit {@code -D...} on the command line always wins over the file.
 * Called as early as possible (agent premain and Pclip.run); safe to call more than once.
 *
 * <p>Only user-tunable options are in the file (watchdog, experimental, mixin.stubAccessors; all default OFF). Compatibility
 * patches are always on and cannot be configured; unknown keys in an old file are ignored.
 */
public final class ModloaderConfig {
	private static final Path FILE = Paths.get("config", "modloader.json");
	private static boolean loaded;

	/** section/key -> {system property, default}. Booleans only, except the watchdog numbers handled below. */
	private static final Map<String, Object[]> BOOLEANS = new LinkedHashMap<>();

	/** compatibility patches: ALWAYS on, not configurable (the hybrid does not boot / plugins crash without them). Forced over any -D. */
	private static final String[] ALWAYS_ON = {
		"ankhangbo.vec3iUnfinal", "ankhangbo.allowDuplicateBlockEntityType", "ankhangbo.transferToPlayer", "ankhangbo.chunkHolderBridge",
		"ankhangbo.voxelShapeLazyInit", "ankhangbo.asyncSpawnStateMobCap", "ankhangbo.log4jScanGuard", "ankhangbo.fabricmods.asplugins",
		"ankhangbo.fabricmods.aliasnames", "ankhangbo.stripJarSignatures",
		
		"ankhangbo.mixin.relax", "ankhangbo.mixin.localsFailSoft", "ankhangbo.mixin.materializeShadows", "ankhangbo.mixin.allowEarlyLoaded"
	};

	static {
		// only user-tunable options live in the file
		b("compat", "moddedMaterials", "ankhangbo.moddedMaterials", true); // Bukkit Material constants for modded blocks/items (WorldGuard, CoreProtect...)
		b("mixin", "stubAccessors", "ankhangbo.mixin.stubAccessors", false);
		b("experimental", "leafAttributeArrayMap", "ankhangbo.leafAttributeArrayMap", false);
		b("watchdog", "enabled", "ankhangbo.watchdog", false);
	}

	private static void b(String section, String key, String prop, boolean def) {
		BOOLEANS.put(section + "." + key, new Object[] {prop, def});
	}

	private ModloaderConfig() { }

	public static synchronized void load() {
		if (loaded) return;
		loaded = true;

		Map<String, Object> values = new LinkedHashMap<>();
		long interval = 10L;
		long max = 360L;

		if (Files.isRegularFile(FILE)) {
			try (Reader r = Files.newBufferedReader(FILE, StandardCharsets.UTF_8); JsonReader in = new JsonReader(r)) {
				in.setLenient(true);
				in.beginObject();

				while (in.hasNext()) {
					String section = in.nextName();

					if (in.peek() != JsonToken.BEGIN_OBJECT) { in.skipValue(); continue; }

					in.beginObject();

					while (in.hasNext()) {
						String key = in.nextName();
						String full = section + "." + key;
						JsonToken t = in.peek();

						if (t == JsonToken.BOOLEAN) values.put(full, in.nextBoolean());
						else if (t == JsonToken.NUMBER) values.put(full, in.nextLong());
						else in.skipValue();
					}

					in.endObject();
				}

				in.endObject();
			} catch (Throwable e) {
				System.err.println("[modloader] cannot read " + FILE + " (" + e + ") - using defaults");
			}
		} else {
			writeDefaults();
		}

		for (String p : ALWAYS_ON) System.setProperty(p, "true");

		for (Map.Entry<String, Object[]> e : BOOLEANS.entrySet()) {
			String prop = (String) e.getValue()[0];
			if (System.getProperty(prop) != null) continue; // explicit -D wins
			Object v = values.get(e.getKey());
			boolean on = v instanceof Boolean ? (Boolean) v : (Boolean) e.getValue()[1];
			System.setProperty(prop, Boolean.toString(on));
		}

		Object iv = values.get("watchdog.intervalSeconds");
		Object mx = values.get("watchdog.maxDumps");
		if (iv instanceof Long) interval = (Long) iv;
		if (mx instanceof Long) max = (Long) mx;
		if (System.getProperty("ankhangbo.watchdog.seconds") == null) System.setProperty("ankhangbo.watchdog.seconds", Long.toString(interval));
		if (System.getProperty("ankhangbo.watchdog.max") == null) System.setProperty("ankhangbo.watchdog.max", Long.toString(max));
	}

	/** reads a switch the same way the patches do (after {@link #load()}) */
	public static boolean enabled(String property, boolean def) {
		String v = System.getProperty(property);
		return v == null ? def : Boolean.parseBoolean(v);
	}

	private static void writeDefaults() {
		StringBuilder sb = new StringBuilder("{\n");
		String lastSection = null;

		for (Map.Entry<String, Object[]> e : BOOLEANS.entrySet()) {
			String[] sk = e.getKey().split("\\.", 2);

			if (!sk[0].equals(lastSection)) {
				if (lastSection != null) sb.append("\n  },\n");
				sb.append("  \"").append(sk[0]).append("\": {\n");
				lastSection = sk[0];
			} else {
				sb.append(",\n");
			}

			sb.append("    \"").append(sk[1]).append("\": ").append(e.getValue()[1]);

			if (sk[0].equals("watchdog") && sk[1].equals("enabled")) {
				sb.append(",\n    \"intervalSeconds\": 10,\n    \"maxDumps\": 360");
			}
		}

		sb.append("\n  }\n}\n");

		try {
			Files.createDirectories(FILE.getParent());
			Files.write(FILE, sb.toString().getBytes(StandardCharsets.UTF_8));
			System.out.println("[modloader] created " + FILE);
		} catch (IOException e) {
			System.err.println("[modloader] cannot create " + FILE + ": " + e);
		}
	}
}
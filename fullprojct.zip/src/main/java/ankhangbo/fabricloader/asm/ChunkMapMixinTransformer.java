package ankhangbo.fabricloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.ArrayList;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Patch ChunkMapMixin.class trong fabric-lifecycle-events-v1.jar (runtime qua agent).
 *
 * Thay toàn bộ class bằng version đã retarget sang Moonrise's NewChunkHolder:
 *  - @Mixin(ChunkMap.class) → @Mixin(targets = "ca.spottedleaf.moonrise...NewChunkHolder")
 *  - @Shadow level → @Shadow world
 *  - @Inject lambda$scheduleUnload$0 → @Inject unloadStage2
 *  - Body thay hoàn toàn
 */
public class ChunkMapMixinTransformer implements ClassFileTransformer {

    private static final String TARGET_CLASS =
        "net/fabricmc/fabric/mixin/event/lifecycle/ChunkMapMixin";

    private static final String NEW_CHUNK_HOLDER =
        "ca/spottedleaf/moonrise/patches/chunk_system/scheduling/NewChunkHolder";

    private static final String NEW_UNLOAD_STATE =
        NEW_CHUNK_HOLDER + "$UnloadState";

    @Override
    public byte[] transform(ClassLoader loader, String className,
                            Class<?> classBeingRedefined,
                            ProtectionDomain protectionDomain,
                            byte[] classfileBuffer) throws IllegalClassFormatException {

        if (!TARGET_CLASS.equals(className)) {
            return null;
        }

        System.out.println("[ChunkMapMixinTransformer] Patching " + className);

        try {
            ClassNode node = new ClassNode();
            new ClassReader(classfileBuffer).accept(node, 0);

            // 1. Xóa @Mixin cũ, thêm @Mixin(targets = NewChunkHolder)
            removeMixinAnnotation(node);
            addMixinAnnotation(node, NEW_CHUNK_HOLDER);

            // 2. Xóa tất cả field cũ, thêm @Shadow @Final world
            node.fields.clear();
            addShadowField(node, "world", "Lnet/minecraft/server/level/ServerLevel;");

            // 3. Xóa tất cả method cũ
            node.methods.clear();

            // 4. Thêm method onChunkUnload mới
            addOnChunkUnloadMethod(node);

            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES) {
                @Override
                protected String getCommonSuperClass(String type1, String type2) {
                    try {
                        return super.getCommonSuperClass(type1, type2);
                    } catch (Throwable t) {
                        return "java/lang/Object";
                    }
                }
            };
            node.accept(writer);
            return writer.toByteArray();
        } catch (Throwable t) {
            System.err.println("[ChunkMapMixinTransformer] Failed: " + t);
            t.printStackTrace();
            return null;
        }
    }

    private void removeMixinAnnotation(ClassNode node) {
        if (node.visibleAnnotations != null) {
            node.visibleAnnotations.removeIf(a -> "Lorg/spongepowered/asm/mixin/Mixin;".equals(a.desc));
        }
        if (node.invisibleAnnotations != null) {
            node.invisibleAnnotations.removeIf(a -> "Lorg/spongepowered/asm/mixin/Mixin;".equals(a.desc));
        }
    }

    private void addMixinAnnotation(ClassNode node, String targetInternalName) {
        AnnotationNode mixin = new AnnotationNode("Lorg/spongepowered/asm/mixin/Mixin;");
        mixin.visit("targets", targetInternalName.replace('/', '.'));
        mixin.visitEnd();
        if (node.visibleAnnotations == null) node.visibleAnnotations = new ArrayList<>();
        node.visibleAnnotations.add(mixin);
    }

    private void addShadowField(ClassNode node, String name, String desc) {
        FieldNode field = new FieldNode(
            Opcodes.ACC_PRIVATE | Opcodes.ACC_FINAL,
            name,
            desc,
            null,
            null
        );
        AnnotationNode shadow = new AnnotationNode("Lorg/spongepowered/asm/mixin/Shadow;");
        shadow.visitEnd();
        AnnotationNode finalAnn = new AnnotationNode("Lorg/spongepowered/asm/mixin/Final;");
        finalAnn.visitEnd();
        field.visibleAnnotations = new ArrayList<>();
        field.visibleAnnotations.add(shadow);
        field.visibleAnnotations.add(finalAnn);
        node.fields.add(field);
    }

    private void addOnChunkUnloadMethod(ClassNode node) {
        MethodNode method = new MethodNode(
            Opcodes.ACC_PRIVATE,
            "onChunkUnload",
            "(L" + NEW_UNLOAD_STATE + ";Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V",
            null,
            null
        );

        // @Inject(method = "unloadStage2", at = @At("HEAD"))
        AnnotationNode inject = new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/Inject;");
        inject.visit("method", "unloadStage2");
        AnnotationNode at = new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/At;");
        at.visit("value", "HEAD");
        at.visitEnd();
        inject.visit("at", at);
        inject.visitEnd();
        method.visibleAnnotations = new ArrayList<>();
        method.visibleAnnotations.add(inject);

        // Body:
        InsnList code = new InsnList();

        // ChunkAccess chunk = unloadState.chunk();
        code.add(new VarInsnNode(Opcodes.ALOAD, 1));
        code.add(new MethodInsnNode(
            Opcodes.INVOKEVIRTUAL,
            NEW_UNLOAD_STATE,
            "chunk",
            "()Lnet/minecraft/world/level/chunk/ChunkAccess;",
            false
        ));
        code.add(new VarInsnNode(Opcodes.ASTORE, 3));

        // if (chunk instanceof LevelChunk levelChunk) {
        code.add(new VarInsnNode(Opcodes.ALOAD, 3));
        code.add(new TypeInsnNode(Opcodes.INSTANCEOF, "net/minecraft/world/level/chunk/LevelChunk"));
        LabelNode skip = new LabelNode();
        code.add(new JumpInsnNode(Opcodes.IFEQ, skip));

        //   ServerChunkEvents.CHUNK_UNLOAD.invoker().onChunkUnload(this.world, levelChunk);
        code.add(new FieldInsnNode(
            Opcodes.GETSTATIC,
            "net/fabricmc/fabric/api/event/lifecycle/v1/ServerChunkEvents",
            "CHUNK_UNLOAD",
            "Lnet/fabricmc/fabric/api/event/Event;"
        ));
        code.add(new MethodInsnNode(
            Opcodes.INVOKEVIRTUAL,
            "net/fabricmc/fabric/api/event/Event",
            "invoker",
            "()Ljava/lang/Object;",
            false
        ));
        code.add(new TypeInsnNode(
            Opcodes.CHECKCAST,
            "net/fabricmc/fabric/api/event/lifecycle/v1/ServerChunkEvents$ChunkUnload"
        ));
        code.add(new VarInsnNode(Opcodes.ALOAD, 0));
        code.add(new FieldInsnNode(
            Opcodes.GETFIELD,
            TARGET_CLASS,
            "world",
            "Lnet/minecraft/server/level/ServerLevel;"
        ));
        code.add(new VarInsnNode(Opcodes.ALOAD, 3));
        code.add(new TypeInsnNode(Opcodes.CHECKCAST, "net/minecraft/world/level/chunk/LevelChunk"));
        code.add(new MethodInsnNode(
            Opcodes.INVOKEINTERFACE,
            "net/fabricmc/fabric/api/event/lifecycle/v1/ServerChunkEvents$ChunkUnload",
            "onChunkUnload",
            "(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/LevelChunk;)V",
            true
        ));

        code.add(skip);
        code.add(new InsnNode(Opcodes.RETURN));

        method.instructions = code;
        method.maxStack = 4;
        method.maxLocals = 4;

        node.methods.add(method);
    }
}
package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Moonrise (Paper/Leaf 26.2) removed {@code ChunkMap.pendingUnloads}, but squaremap still declares an {@code @Accessor} for it
 * (ChunkMapAccess#squaremap$pendingUnloads) and Mixin aborts the ChunkMap transformation ("No candidates were found matching
 * pendingUnloads"), which crashes the server when the first world is created.
 * Re-adds the field as an always-empty {@code Long2ObjectLinkedOpenHashMap} (created in every constructor that calls super), because
 * chunk unloading is handled by Moonrise now: a mod that reads it simply sees "nothing pending".
 *
 * <p>Same treatment as {@link ServerLevelEntityManagerFieldTransformer}: run from the {@link GameClassPatcher} chain and from
 * {@code GameClassPatcher.applyMixinVisible}; a second pass finds the field and does nothing.</p>
 */
public final class ChunkMapPendingUnloadsFieldTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.ChunkMapPendingUnloadsFieldTransformer");
	private static final String TARGET = "net/minecraft/server/level/ChunkMap";
	private static final String FIELD = "pendingUnloads";
	private static final String MAP = "it/unimi/dsi/fastutil/longs/Long2ObjectLinkedOpenHashMap";
	private static final String DESC = "L" + MAP + ";";

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain pd, byte[] buf) {
		if (!TARGET.equals(className)) return null;

		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);

			for (FieldNode f : cn.fields) {
				if (f.name.equals(FIELD)) return null;
			}

			int ctors = 0;

			for (MethodNode m : cn.methods) {
				if (!m.name.equals("<init>")) continue;

				for (AbstractInsnNode in : m.instructions.toArray()) {
					if (in instanceof MethodInsnNode mi && mi.getOpcode() == Opcodes.INVOKESPECIAL && mi.name.equals("<init>") && mi.owner.equals(cn.superName)) {
						InsnList init = new InsnList();
						init.add(new VarInsnNode(Opcodes.ALOAD, 0));
						init.add(new TypeInsnNode(Opcodes.NEW, MAP));
						init.add(new InsnNode(Opcodes.DUP));
						init.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, MAP, "<init>", "()V", false));
						init.add(new FieldInsnNode(Opcodes.PUTFIELD, TARGET, FIELD, DESC));
						m.instructions.insert(in, init);
						ctors++;
						break;
					}
				}
			}

			if (ctors == 0) {
				LOGGER.warning("ChunkMap: no constructor calling super() found - pendingUnloads NOT re-added");
				return null;
			}

			cn.fields.add(new FieldNode(Opcodes.ACC_PRIVATE, FIELD, DESC, null, null));
			ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(w);
			LOGGER.info("PATCHED " + className + " (re-added removed field " + FIELD + ", empty map; squaremap still references it)");
			return w.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}
}
package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Fixes {@code [voicechat] Failed to use fabric-permission-api-v1 / NullPointerException: ...
 * PermissionContextOwner.getPermissionContext() is null} (thrown while Paper's async command builder asks
 * {@code CommandNode#canUse(source)}).
 *
 * <p>fabric-permission-api-v1's {@code CommandSourceStackMixin} keeps its state in three {@code @Unique} fields
 * (context / sourceType / sourceUuid) that are only assigned by field initialisers Mixin copies into the
 * constructors. For a source that did not go through those constructors the three getters return null.
 *
 * <p>Every getter is rewritten to {@code field != null ? field : default}, where the default is what the constructor
 * would have produced: a fresh {@code CommandPermissionContext(this)} (stored, so it is created once; the field's
 * {@code final} flag is dropped for that), {@code PermissionContext.Type.SYSTEM}, {@code Util.NIL_UUID}. The field
 * is read out of the getter's own GETFIELD, so it works whatever name Mixin gave the {@code @Unique} member.
 * Hand-written F_SAME1 frames; nothing is loaded while the class is being defined.
 */
public final class CommandSourceStackPermissionContextTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger(
			"ankhangbo.fabricloader.asm.CommandSourceStackPermissionContextTransformer");

	private static final String TARGET = "net/minecraft/commands/CommandSourceStack";
	/** fabric-permission-api-v1 also makes every Entity (so Player/ServerPlayer) a PermissionContextOwner, with the same @Unique-field pattern */
	private static final String ENTITY = "net/minecraft/world/entity/Entity";
	private static final String CONTEXT = "net/fabricmc/fabric/api/permission/v1/PermissionContext";
	private static final String CONTEXT_IMPL = "net/fabricmc/fabric/impl/permission/CommandPermissionContext";

	@Override
	@SuppressWarnings("unchecked")
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
			ProtectionDomain protectionDomain, byte[] classfileBuffer) {
		if (ENTITY.equals(className)) {
			return transformEntity(classfileBuffer);
		}
		if (!TARGET.equals(className)) {
			return null;
		}
		try {
			ClassNode cn = new ClassNode();
			new ClassReader(classfileBuffer).accept(cn, 0);
			int patched = 0;
			for (MethodNode m : (List<MethodNode>) cn.methods) {
				if ((m.access & Opcodes.ACC_STATIC) != 0) {
					continue;
				}
				if (m.name.equals("getPermissionContext") && m.desc.equals("()L" + CONTEXT + ";")) {
					patched += rewrite(cn, m, "L" + CONTEXT + ";", CONTEXT, Kind.CONTEXT);
				} else if (m.name.equals("fabric_getType") && m.desc.equals("()L" + CONTEXT + "$Type;")) {
					patched += rewrite(cn, m, "L" + CONTEXT + "$Type;", CONTEXT + "$Type", Kind.TYPE);
				} else if (m.name.equals("fabric_getUuid") && m.desc.equals("()Ljava/util/UUID;")) {
					patched += rewrite(cn, m, "Ljava/util/UUID;", "java/util/UUID", Kind.UUID);
				}
			}
			if (patched == 0) {
				return null; // fabric-permission-api-v1 not present
			}
			ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(w);
			LOGGER.info("PATCHED CommandSourceStack: permission context getters never return null (" + patched + " getter(s))");
			return w.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}

	/**
	 * Entity: the context's class is not known here, so the default is built exactly like the constructor builds it: the
	 * {@code NEW X; DUP; ALOAD 0; INVOKESPECIAL X.<init>} run in front of the PUTFIELD that Mixin copied into the constructor is reused.
	 */
	@SuppressWarnings("unchecked")
	private static byte[] transformEntity(byte[] buf) {
		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);

			for (MethodNode m : (List<MethodNode>) cn.methods) {
				if ((m.access & Opcodes.ACC_STATIC) != 0 || !m.name.equals("getPermissionContext") || !m.desc.equals("()L" + CONTEXT + ";")) {
					continue;
				}

				FieldInsnNode get = null;
				for (AbstractInsnNode insn : m.instructions.toArray()) {
					if (insn.getOpcode() == Opcodes.GETFIELD && ((FieldInsnNode) insn).owner.equals(cn.name)) {
						get = (FieldInsnNode) insn;
						break;
					}
				}
				if (get == null) {
					return null;
				}

				InsnList make = null;
				for (MethodNode c : (List<MethodNode>) cn.methods) {
					if (!c.name.equals("<init>")) {
						continue;
					}
					for (AbstractInsnNode insn : c.instructions.toArray()) {
						if (insn.getOpcode() != Opcodes.PUTFIELD || !((FieldInsnNode) insn).name.equals(get.name) || !((FieldInsnNode) insn).desc.equals(get.desc)) {
							continue;
						}
						AbstractInsnNode init = insn.getPrevious();
						while (init != null && init.getOpcode() < 0) {
							init = init.getPrevious();
						}
						if (!(init instanceof MethodInsnNode) || init.getOpcode() != Opcodes.INVOKESPECIAL) {
							continue;
						}
						AbstractInsnNode start = init;
						while (start != null && !(start.getOpcode() == Opcodes.NEW && ((TypeInsnNode) start).desc.equals(((MethodInsnNode) init).owner))) {
							start = start.getPrevious();
						}
						if (start == null) {
							continue;
						}
						make = new InsnList();
						java.util.Map<LabelNode, LabelNode> none = new java.util.HashMap<>();
						for (AbstractInsnNode n = start; ; n = n.getNext()) {
							if (n.getOpcode() >= 0) {
								make.add(n.clone(none));
							}
							if (n == init) {
								break;
							}
						}
						break;
					}
					if (make != null) {
						break;
					}
				}
				if (make == null) {
					LOGGER.warning("Entity.getPermissionContext: could not find how the constructor creates the context - NOT patched");
					return null;
				}

				for (FieldNode f : (List<FieldNode>) cn.fields) {
					if (f.name.equals(get.name) && f.desc.equals(get.desc)) {
						f.access &= ~Opcodes.ACC_FINAL;
					}
				}

				String frameType = org.objectweb.asm.Type.getType(get.desc).getInternalName();
				LabelNode done = new LabelNode();
				InsnList b = new InsnList();
				b.add(new VarInsnNode(Opcodes.ALOAD, 0));
				b.add(new FieldInsnNode(Opcodes.GETFIELD, get.owner, get.name, get.desc));
				b.add(new InsnNode(Opcodes.DUP));
				b.add(new JumpInsnNode(Opcodes.IFNONNULL, done));
				b.add(new InsnNode(Opcodes.POP));
				b.add(new VarInsnNode(Opcodes.ALOAD, 0));
				b.add(make); // [this, ctx]
				b.add(new InsnNode(Opcodes.DUP_X1)); // [ctx, this, ctx]
				b.add(new FieldInsnNode(Opcodes.PUTFIELD, get.owner, get.name, get.desc));
				b.add(done);
				b.add(new FrameNode(Opcodes.F_SAME1, 0, null, 1, new Object[] { frameType }));
				b.add(new InsnNode(Opcodes.ARETURN));
				m.instructions = b;
				m.tryCatchBlocks.clear();
				m.localVariables = null;

				ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
				cn.accept(w);
				LOGGER.info("PATCHED Entity: getPermissionContext() never returns null");
				return w.toByteArray();
			}
			return null; // fabric-permission-api-v1 not present
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + ENTITY, t);
			return null;
		}
	}

	private enum Kind { CONTEXT, TYPE, UUID }

	@SuppressWarnings("unchecked")
	private static int rewrite(ClassNode cn, MethodNode m, String fieldDesc, String frameType, Kind kind) {
		FieldInsnNode field = null;
		for (AbstractInsnNode insn : m.instructions.toArray()) {
			if (insn.getOpcode() == Opcodes.GETFIELD && ((FieldInsnNode) insn).desc.equals(fieldDesc)) {
				field = (FieldInsnNode) insn;
				break;
			}
		}
		if (field == null) {
			return 0;
		}
		LabelNode done = new LabelNode();
		InsnList b = new InsnList();
		b.add(new VarInsnNode(Opcodes.ALOAD, 0));
		b.add(new FieldInsnNode(Opcodes.GETFIELD, field.owner, field.name, field.desc));
		b.add(new InsnNode(Opcodes.DUP));
		b.add(new JumpInsnNode(Opcodes.IFNONNULL, done));
		b.add(new InsnNode(Opcodes.POP));
		switch (kind) {
			case CONTEXT:
				for (FieldNode f : (List<FieldNode>) cn.fields) {
					if (f.name.equals(field.name) && f.desc.equals(field.desc)) {
						f.access &= ~Opcodes.ACC_FINAL; // we assign it outside a constructor
					}
				}
				b.add(new VarInsnNode(Opcodes.ALOAD, 0));
				b.add(new TypeInsnNode(Opcodes.NEW, CONTEXT_IMPL));
				b.add(new InsnNode(Opcodes.DUP));
				b.add(new VarInsnNode(Opcodes.ALOAD, 0));
				b.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, CONTEXT_IMPL, "<init>",
						"(Lnet/minecraft/commands/CommandSourceStack;)V", false));
				b.add(new InsnNode(Opcodes.DUP_X1)); // [ctx, this, ctx]
				b.add(new FieldInsnNode(Opcodes.PUTFIELD, field.owner, field.name, field.desc));
				break;
			case TYPE:
				b.add(new FieldInsnNode(Opcodes.GETSTATIC, CONTEXT + "$Type", "SYSTEM", "L" + CONTEXT + "$Type;"));
				break;
			default:
				b.add(new FieldInsnNode(Opcodes.GETSTATIC, "net/minecraft/util/Util", "NIL_UUID", "Ljava/util/UUID;"));
		}
		b.add(done);
		b.add(new FrameNode(Opcodes.F_SAME1, 0, null, 1, new Object[] { frameType }));
		b.add(new InsnNode(Opcodes.ARETURN));
		m.instructions = b;
		m.tryCatchBlocks.clear();
		m.localVariables = null;
		return 1;
	}
}
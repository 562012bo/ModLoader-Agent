package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DIAGNOSTIC (temporary): {@code net.minecraft.network.Connection#exceptionCaught} turns a pipeline exception into the one-line
 * "lost connection: Internal Exception: ..." and only logs the stack at debug level, so the origin of e.g. "Unknown addon" is invisible.
 * Prints the full stack trace of every such exception to stderr. Remove this transformer (and its CHAIN entry) once the cause is found.
 */
public final class ConnectionExceptionTraceTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.ConnectionExceptionTraceTransformer");
	private static final String TARGET = "net/minecraft/network/Connection";
	private static final String DESC = "(Lio/netty/channel/ChannelHandlerContext;Ljava/lang/Throwable;)V";

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain pd, byte[] buf) {
		if (!TARGET.equals(className)) return null;

		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);

			for (MethodNode m : cn.methods) {
				if (m.name.equals("exceptionCaught") && m.desc.equals(DESC)) {
					InsnList il = new InsnList();
					il.add(new VarInsnNode(Opcodes.ALOAD, 2));
					il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "java/lang/Throwable", "printStackTrace", "()V", false));
					m.instructions.insert(il);
					ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
					cn.accept(w);
					LOGGER.info("PATCHED " + className + " (diagnostic: prints the stack trace of connection exceptions)");
					return w.toByteArray();
				}
			}

			LOGGER.warning("Connection.exceptionCaught not found - diagnostic NOT applied");
			return null;
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}
}
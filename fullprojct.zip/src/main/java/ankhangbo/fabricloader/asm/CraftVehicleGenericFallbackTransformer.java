package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Strips the {@code abstract} flag from {@code CraftMinecart} and {@code CraftVehicle} so they can be instantiated as the generic Bukkit
 * wrapper of a modded minecart / vehicle entity (Railways' handcar, ...). Same idea as {@link CraftBoatGenericFallbackTransformer}:
 * {@code AbstractMinecart} code does {@code (Vehicle) this.getBukkitEntity()}, which fails with
 * {@code ClassCastException: CraftEntity cannot be cast to org.bukkit.entity.Vehicle} when the wrapper is the plain CraftEntity. Both classes
 * declare no abstract methods; the vanilla subclasses (CraftMinecartRideable, ...) only add marker interfaces.
 * {@link ankhangbo.fabricloader.compat.CraftEntityResolver} then picks them for modded subclasses of AbstractMinecart / VehicleEntity.
 */
public final class CraftVehicleGenericFallbackTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.CraftVehicleGenericFallbackTransformer");

	private static final class SafeClassWriter extends ClassWriter {
		private final ClassLoader targetLoader;

		SafeClassWriter(int flags, ClassLoader targetLoader) {
			super(flags);
			this.targetLoader = targetLoader;
		}

		@Override
		protected String getCommonSuperClass(String type1, String type2) {
			Class<?> class1;
			Class<?> class2;
			try {
				class1 = Class.forName(type1.replace('/', '.'), false, targetLoader);
				class2 = Class.forName(type2.replace('/', '.'), false, targetLoader);
			} catch (Throwable t) {
				return "java/lang/Object";
			}
			if (class1.isAssignableFrom(class2)) {
				return type1;
			}
			if (class2.isAssignableFrom(class1)) {
				return type2;
			}
			if (class1.isInterface() || class2.isInterface()) {
				return "java/lang/Object";
			}
			do {
				class1 = class1.getSuperclass();
			} while (!class1.isAssignableFrom(class2));
			return class1.getName().replace('.', '/');
		}
	}

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) {
		if (!"org/bukkit/craftbukkit/entity/CraftMinecart".equals(className) && !"org/bukkit/craftbukkit/entity/CraftVehicle".equals(className)) {
			return null;
		}

		try {
			ClassNode classNode = new ClassNode();
			new ClassReader(classfileBuffer).accept(classNode, 0);

			if ((classNode.access & Opcodes.ACC_ABSTRACT) == 0) {
				return null;
			}

			classNode.access &= ~Opcodes.ACC_ABSTRACT;
			ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
			classNode.accept(writer);
			LOGGER.info("PATCHED " + className + " (instantiable as the generic wrapper of modded minecarts/vehicles)");
			return writer.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to make " + className + " instantiable - leaving it unpatched", t);
			return null;
		}
	}
}
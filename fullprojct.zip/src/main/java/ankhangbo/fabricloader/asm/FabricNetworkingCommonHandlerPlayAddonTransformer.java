package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Fixes the kick {@code Internal Exception: java.lang.IllegalStateException: Unknown addon} of a client that has Jade (or any mod whose custom payload
 * Fabric's play addon does not consume).
 *
 * <p>fabric-networking-api-v1 injects {@code ServerCommonPacketListenerImplMixin#handleCustomPayloadReceivedAsync} at the head of
 * {@code ServerCommonPacketListenerImpl.handleCustomPayload}. That handler only knows the configuration-phase addon and throws
 * "Unknown addon" for anything else, because in vanilla/Fabric nothing reaches it during play: {@code ServerGamePacketListenerImpl}
 * overrides {@code handleCustomPayload} (empty) and has its own handler (ServerGamePacketListenerImplMixin) for the play addon.
 * Paper/Leaf's override calls {@code super.handleCustomPayload(packet)} for payloads that the play addon did not consume (plugin messages,
 * Leaf protocols, ...), so those now arrive in the configuration-only handler and the player is disconnected.</p>
 *
 * <p>The {@code throw new IllegalStateException("Unknown addon")} in that handler becomes a plain {@code return}: for a non-configuration
 * listener the handler does nothing and Paper's own code runs. The throw sits in the else branch with an empty stack, and the join point
 * after it stays reachable through the other branch, so no frame changes.</p>
 */
public final class FabricNetworkingCommonHandlerPlayAddonTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.FabricNetworkingCommonHandlerPlayAddonTransformer");
	private static final String TARGET = "net/minecraft/server/network/ServerCommonPacketListenerImpl";

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain pd, byte[] buf) {
		if (!TARGET.equals(className)) return null;

		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);
			int patched = 0;

			for (MethodNode m : cn.methods) {
				if (!m.name.contains("handleCustomPayloadReceivedAsync") || !m.name.contains("networking") || m.instructions == null) continue;

				for (AbstractInsnNode in : m.instructions.toArray()) {
					if (!(in instanceof LdcInsnNode ldc) || !"Unknown addon".equals(ldc.cst)) continue;

					// NEW IllegalStateException, DUP, LDC "Unknown addon", INVOKESPECIAL <init>, ATHROW
					AbstractInsnNode init = ldc.getNext();
					AbstractInsnNode athrow = init == null ? null : init.getNext();
					AbstractInsnNode dup = ldc.getPrevious();
					AbstractInsnNode neu = dup == null ? null : dup.getPrevious();

					if (athrow == null || athrow.getOpcode() != Opcodes.ATHROW || dup.getOpcode() != Opcodes.DUP
							|| !(neu instanceof TypeInsnNode t) || t.getOpcode() != Opcodes.NEW) continue;

					m.instructions.remove(neu);
					m.instructions.remove(dup);
					m.instructions.remove(ldc);
					m.instructions.remove(init);
					m.instructions.set(athrow, new InsnNode(Opcodes.RETURN));
					patched++;
				}
			}

			if (patched == 0) return null; // fabric-networking-api-v1 absent or already patched

			ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(w);
			LOGGER.info("PATCHED " + className + " (fabric-networking-api-v1 handler no longer throws 'Unknown addon' during play; Paper handles those payloads)");
			return w.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}
}
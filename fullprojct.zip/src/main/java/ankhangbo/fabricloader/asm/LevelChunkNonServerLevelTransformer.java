package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.LocalVariableNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

import java.io.InputStream;
import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Paper changed {@code LevelChunk.level} from {@code Level} to {@code ServerLevel} and the constructor does
 * {@code this.level = (ServerLevel) level}. Mods that build a LevelChunk for their own Level (Create's SchematicChunkSource.EmptierChunk
 * over its DummyLevel) get a {@code ClassCastException}.
 *
 * <p>This adds a second field {@code ankhangbo$level} (type {@code Level}, vanilla's original) that the constructor always fills, makes
 * the old field null for non-ServerLevel (via an added static {@code ankhangbo$asServer}), and redirects every read of {@code level} in
 * LevelChunk to the new field, followed by {@code CHECKCAST ServerLevel} wherever the Paper code needs the narrower type (so ServerLevel
 * chunks behave exactly as before, and {@code getLevel()} / Level-typed uses work for any Level).</p>
 */
public final class LevelChunkNonServerLevelTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.LevelChunkNonServerLevelTransformer");
	private static final String CHUNK = "net/minecraft/world/level/chunk/LevelChunk";
	private static final String LEVEL = "net/minecraft/world/level/Level";
	private static final String SERVER_LEVEL = "net/minecraft/server/level/ServerLevel";
	private static final String FIELD = "ankhangbo$level";
	private static final String AS_SERVER = "ankhangbo$asServer";

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain pd, byte[] buf) {
		if (!CHUNK.equals(className)) return null;

		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);

			for (FieldNode f : cn.fields) {
				if (f.name.equals(FIELD)) return null;
			}

			Set<String> levelMembers = new HashSet<>();
			collectMembers(loader, LEVEL, levelMembers);

			if (levelMembers.isEmpty()) LOGGER.warning("LevelChunk: could not read net/minecraft/world/level/Level - ServerLevel casts are kept everywhere");

			boolean ctor = false;
			int reads = 0;

			for (MethodNode m : cn.methods) {
				for (AbstractInsnNode in : m.instructions.toArray()) {
					if (!(in instanceof FieldInsnNode f) || !f.owner.equals(CHUNK) || !f.name.equals("level")
							|| !f.desc.equals("L" + SERVER_LEVEL + ";")) continue;

					if (f.getOpcode() == Opcodes.PUTFIELD) {
						AbstractInsnNode cast = f.getPrevious();
						AbstractInsnNode load = cast == null ? null : cast.getPrevious();

						if (cast instanceof TypeInsnNode c && c.getOpcode() == Opcodes.CHECKCAST && c.desc.equals(SERVER_LEVEL)
								&& load instanceof VarInsnNode v && v.getOpcode() == Opcodes.ALOAD) {
							m.instructions.set(cast, new MethodInsnNode(Opcodes.INVOKESTATIC, CHUNK, AS_SERVER, "(L" + LEVEL + ";)L" + SERVER_LEVEL + ";", false));
							InsnList add = new InsnList();
							add.add(new VarInsnNode(Opcodes.ALOAD, 0));
							add.add(new VarInsnNode(Opcodes.ALOAD, v.var));
							add.add(new FieldInsnNode(Opcodes.PUTFIELD, CHUNK, FIELD, "L" + LEVEL + ";"));
							m.instructions.insert(f, add);
							ctor = true;
						}
					} else if (f.getOpcode() == Opcodes.GETFIELD) {
						f.name = FIELD;
						f.desc = "L" + LEVEL + ";";

						if (!plainLevelUse(loader, m, f, levelMembers)) {
							m.instructions.insert(f, new MethodInsnNode(Opcodes.INVOKESTATIC, CHUNK, AS_SERVER, "(L" + LEVEL + ";)L" + SERVER_LEVEL + ";", false));
						}

						reads++;
					}
				}
			}

			if (!ctor) {
				LOGGER.warning("LevelChunk: constructor 'this.level = (ServerLevel) level' not found - non-ServerLevel chunks NOT supported");
				return null;
			}

			cn.fields.add(new FieldNode(Opcodes.ACC_PRIVATE | Opcodes.ACC_SYNTHETIC, FIELD, "L" + LEVEL + ";", null, null));
			cn.methods.add(asServerMethod());
			ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(w);
			LOGGER.info("PATCHED " + className + " (accepts any Level: " + reads + " reads of 'level' redirected to the Level-typed field)");
			return w.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}

	/**
	 * true when the value read is provably only used as a plain Level: returned, stored in a local the debug info types as Level, or the
	 * receiver of a call to a method that Level itself has (then the call's owner is rewritten to Level so no ServerLevel is needed).
	 */
	private static boolean plainLevelUse(ClassLoader loader, MethodNode m, FieldInsnNode get, Set<String> levelMembers) {
		AbstractInsnNode next = get.getNext();
		if (next == null) return false;
		if (next.getOpcode() == Opcodes.ARETURN) return true;

		// "Level level = this.level;" : frames use the declared type of the local
		if (next instanceof VarInsnNode st && st.getOpcode() == Opcodes.ASTORE && m.localVariables != null) {
			int at = m.instructions.indexOf(next);

			for (LocalVariableNode lv : m.localVariables) {
				if (lv.index == st.var && lv.desc.equals("L" + LEVEL + ";") && m.instructions.indexOf(lv.start) <= at + 1 && m.instructions.indexOf(lv.end) > at) return true;
			}

			return false;
		}

		// walk the straight-line expression to the call that consumes the value
		int above = 0;

		for (AbstractInsnNode in = next; in != null; in = in.getNext()) {
			int op = in.getOpcode();

			if (op < 0) continue; // label / line number / frame

			if ((op >= Opcodes.ACONST_NULL && op <= Opcodes.LDC) || (op >= Opcodes.ILOAD && op <= Opcodes.ALOAD) || op == Opcodes.GETSTATIC) {
				above++;
			} else if (op == Opcodes.GETFIELD) {
				if (above == 0) {
					FieldInsnNode fi = (FieldInsnNode) in;
					if (!fi.owner.equals(SERVER_LEVEL) || !levelMembers.contains("." + fi.name + ":" + fi.desc)) return false;
					fi.owner = LEVEL; // a field Level itself has (e.g. spigotConfig, simpleRandom)
					return true;
				}
			} else if (op == Opcodes.INSTANCEOF) {
				return above == 0;
			} else if (op >= Opcodes.IADD && op <= Opcodes.DREM || op >= Opcodes.ISHL && op <= Opcodes.LXOR) {
				if (above < 2) return false;
				above--;
			} else if (op == Opcodes.INVOKESTATIC || op == Opcodes.INVOKESPECIAL) {
				MethodInsnNode mi = (MethodInsnNode) in;
				Type[] args = Type.getArgumentTypes(mi.desc);
				return above < args.length && levelMembers.contains("T:" + args[args.length - 1 - above].getInternalName());
			} else if (op == Opcodes.INVOKEVIRTUAL || op == Opcodes.INVOKEINTERFACE) {
				MethodInsnNode mi = (MethodInsnNode) in;
				Type[] args = Type.getArgumentTypes(mi.desc);

				if (above < args.length) { // our value is an argument: fine when the parameter is Level (or a supertype of it)
					Type a = args[args.length - 1 - above];
					return a.getSort() == Type.OBJECT && levelMembers.contains("T:" + a.getInternalName());
				}

				if (args.length != above) return false;

				if (mi.owner.equals(SERVER_LEVEL)) {
					if (levelMembers.isEmpty() || !levelMembers.contains(mi.name + mi.desc)) return false;
					mi.owner = LEVEL; // inherited from Level: no ServerLevel needed
					mi.itf = false;
				}

				return true;
			} else if (op == Opcodes.IF_ACMPEQ || op == Opcodes.IF_ACMPNE) {
				return above == 1; // reference comparison only
			} else if (op == Opcodes.IFNULL || op == Opcodes.IFNONNULL) {
				return above == 0;
			} else {
				return false;
			}
		}

		return false;
	}

	/** the class file from the given loader, else the context loader, else the game jar named by -Dfabric.gameJarPath.server (the agent's patch hook runs with no loader) */
	private static InputStream open(ClassLoader loader, String internal) throws java.io.IOException {
		String res = internal + ".class";

		for (ClassLoader l : new ClassLoader[] { loader, Thread.currentThread().getContextClassLoader(), ClassLoader.getSystemClassLoader() }) {
			if (l == null) continue;
			InputStream in = l.getResourceAsStream(res);
			if (in != null) return in;
		}

		String jar = System.getProperty("fabric.gameJarPath.server");

		if (jar != null) {
			try (java.util.zip.ZipFile zf = new java.util.zip.ZipFile(jar)) {
				java.util.zip.ZipEntry e = zf.getEntry(res);
				if (e != null) return new java.io.ByteArrayInputStream(zf.getInputStream(e).readAllBytes());
			}
		}

		return null;
	}

	/** name+desc of every method of the class, its superclasses and interfaces (read from the class path; empty set if unavailable) */
	private static void collectMembers(ClassLoader loader, String internal, Set<String> out) {
		if (internal == null) return;

		try (InputStream in = open(loader, internal)) {
			if (in == null) return;
			ClassNode c = new ClassNode();
			new ClassReader(in).accept(c, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);

			out.add("T:" + internal);

			for (MethodNode mm : c.methods) {
				out.add(mm.name + mm.desc);
			}

			for (org.objectweb.asm.tree.FieldNode ff : c.fields) {
				out.add("." + ff.name + ":" + ff.desc);
			}

			collectMembers(loader, c.superName, out);

			for (String i : c.interfaces) {
				collectMembers(loader, i, out);
			}
		} catch (Throwable t) {
			// partial info only; unknown methods keep their ServerLevel cast
		}
	}

	/** {@code static ServerLevel ankhangbo$asServer(Level l)} : the level if it is a ServerLevel, else null */
	private static MethodNode asServerMethod() {
		MethodNode m = new MethodNode(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_SYNTHETIC, AS_SERVER, "(L" + LEVEL + ";)L" + SERVER_LEVEL + ";", null, null);
		LabelNode no = new LabelNode();
		InsnList il = new InsnList();
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new TypeInsnNode(Opcodes.INSTANCEOF, SERVER_LEVEL));
		il.add(new JumpInsnNode(Opcodes.IFEQ, no));
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new TypeInsnNode(Opcodes.CHECKCAST, SERVER_LEVEL));
		il.add(new InsnNode(Opcodes.ARETURN));
		il.add(no);
		il.add(new FrameNode(Opcodes.F_SAME, 0, null, 0, null));
		il.add(new InsnNode(Opcodes.ACONST_NULL));
		il.add(new InsnNode(Opcodes.ARETURN));
		m.instructions = il;
		return m;
	}
}
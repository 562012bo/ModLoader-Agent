package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Lets mods subclass {@code net.minecraft.world.level.Level} directly (Create's WrappedLevel/SchematicLevel, Railways' handcar, ...),
 * which a vanilla/Fabric server allows but Paper/Leaf break in two ways:
 * <ol>
 *   <li><b>NoSuchMethodError</b>: the constructor {@code Level(WritableLevelData, ResourceKey, RegistryAccess, Holder, boolean, boolean,
 *       long, int)} was replaced by one with extra Bukkit/Paper/Gale parameters. This adds the original 8-argument constructor back; it
 *       forwards to the real one with defaults (bukkit name "world", no generator/biome provider, {@code Environment.NORMAL}, the
 *       overworld's Paper/Gale world config, a direct executor - see {@link ankhangbo.fabricloader.compat.ModdedLevels}).</li>
 *   <li><b>ClassCastException</b>: the real constructor does {@code new CraftWorld((ServerLevel) this, ...)}, which fails for any Level
 *       that is not a ServerLevel. The cast+construction becomes a call to an added static
 *       {@code ankhangbo$createWorld(Level, NamespacedKey, BiomeProvider, Environment)} that returns null for non-ServerLevel.</li>
 * </ol>
 * No branches are added to existing methods (no frame changes); the one new branch is in the added static method, with a hand-written
 * frame.
 */
public final class LevelModdedSubclassCompatTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.LevelModdedSubclassCompatTransformer");
	private static final String LEVEL = "net/minecraft/world/level/Level";
	private static final String SERVER_LEVEL = "net/minecraft/server/level/ServerLevel";
	private static final String CRAFT_WORLD = "org/bukkit/craftbukkit/CraftWorld";
	private static final String RESOURCE_KEY = "net/minecraft/resources/ResourceKey";
	private static final String HELPER = "ankhangbo/fabricloader/compat/ModdedLevels";
	private static final String PREFIX = "Lnet/minecraft/world/level/storage/WritableLevelData;Lnet/minecraft/resources/ResourceKey;"
			+ "Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/core/Holder;ZZJI";

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain pd, byte[] buf) {
		if (!LEVEL.equals(className)) return null;

		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);
			String bridgeDesc = "(" + PREFIX + ")V";
			MethodNode full = null;

			for (MethodNode m : cn.methods) {
				if (!m.name.equals("<init>")) continue;
				if (m.desc.equals(bridgeDesc)) return null; // already there
				if (m.desc.startsWith("(" + PREFIX) && Type.getArgumentTypes(m.desc).length > 8) full = m;
			}

			if (full == null) {
				LOGGER.warning("Level has no extended constructor starting with the vanilla parameters - subclass compat NOT applied");
				return null;
			}

			// 1) CraftWorld creation -> null-tolerant static helper
			boolean worldPatched = false;

			for (AbstractInsnNode in : full.instructions.toArray()) {
				if (in instanceof TypeInsnNode t && t.getOpcode() == Opcodes.NEW && t.desc.equals(CRAFT_WORLD)) {
					AbstractInsnNode dup = t.getNext();
					AbstractInsnNode aload = dup == null ? null : dup.getNext();
					AbstractInsnNode cast = aload == null ? null : aload.getNext();

					if (dup == null || dup.getOpcode() != Opcodes.DUP || aload.getOpcode() != Opcodes.ALOAD
							|| !(cast instanceof TypeInsnNode c) || c.getOpcode() != Opcodes.CHECKCAST || !c.desc.equals(SERVER_LEVEL)) continue;

					AbstractInsnNode init = cast.getNext();

					while (init != null && !(init instanceof MethodInsnNode mi && mi.getOpcode() == Opcodes.INVOKESPECIAL && mi.owner.equals(CRAFT_WORLD) && mi.name.equals("<init>"))) {
						init = init.getNext();
					}

					if (init == null) continue;

					MethodInsnNode ctor = (MethodInsnNode) init;
					String createDesc = "(L" + LEVEL + ";" + ctor.desc.substring(ctor.desc.indexOf(';') + 1, ctor.desc.length() - 2) + ")L" + CRAFT_WORLD + ";";
					full.instructions.remove(t);
					full.instructions.remove(dup);
					full.instructions.remove(cast);
					full.instructions.set(ctor, new MethodInsnNode(Opcodes.INVOKESTATIC, LEVEL, "ankhangbo$createWorld", createDesc, false));
					cn.methods.add(createWorldMethod(createDesc, ctor.desc));
					worldPatched = true;
					break;
				}
			}

			if (!worldPatched) {
				LOGGER.warning("Level's constructor has no 'new CraftWorld((ServerLevel) this, ...)' - non-ServerLevel subclasses may still fail");
			}

			// 1b) vanilla allows a null dimension key (Create's DummyLevel); Paper does dimension.identifier() -> null-tolerant helper
			for (AbstractInsnNode in : full.instructions.toArray()) {
				if (in instanceof MethodInsnNode mi && mi.getOpcode() == Opcodes.INVOKEVIRTUAL && mi.owner.equals(RESOURCE_KEY) && mi.name.equals("identifier")) {
					String helperDesc = "(L" + RESOURCE_KEY + ";)" + Type.getReturnType(mi.desc).getDescriptor();
					full.instructions.set(mi, new MethodInsnNode(Opcodes.INVOKESTATIC, LEVEL, "ankhangbo$worldId", helperDesc, false));
					cn.methods.add(worldIdMethod(helperDesc, mi.desc));
					break;
				}
			}

			// 2) the vanilla 8-argument constructor
			MethodNode bridge = new MethodNode(Opcodes.ACC_PROTECTED, "<init>", bridgeDesc, null, null);
			InsnList il = new InsnList();
			il.add(new VarInsnNode(Opcodes.ALOAD, 0));
			int slot = 1;

			for (Type t : Type.getArgumentTypes(bridgeDesc)) {
				il.add(new VarInsnNode(t.getOpcode(Opcodes.ILOAD), slot));
				slot += t.getSize();
			}

			Type[] fullArgs = Type.getArgumentTypes(full.desc);
			int functions = 0;

			for (int i = 8; i < fullArgs.length; i++) {
				String d = fullArgs[i].getDescriptor();

				switch (d) {
					case "Ljava/lang/String;" -> il.add(new LdcInsnNode("world"));
					case "Lorg/bukkit/World$Environment;" -> il.add(new FieldInsnNode(Opcodes.GETSTATIC, "org/bukkit/World$Environment", "NORMAL", d));
					case "Ljava/util/function/Function;" -> {
						il.add(new LdcInsnNode(Type.getObjectType(LEVEL)));
						il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "java/lang/Class", "getClassLoader", "()Ljava/lang/ClassLoader;", false));
						il.add(new LdcInsnNode(functions++ == 0 ? "paper" : "gale"));
						il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HELPER, "configFactory", "(Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/util/function/Function;", false));
					}
					case "Ljava/util/concurrent/Executor;" -> il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HELPER, "directExecutor", "()Ljava/util/concurrent/Executor;", false));
					default -> il.add(new InsnNode(Opcodes.ACONST_NULL)); // ChunkGenerator, BiomeProvider, anything unknown
				}
			}

			il.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, LEVEL, "<init>", full.desc, false));
			il.add(new InsnNode(Opcodes.RETURN));
			bridge.instructions = il;
			cn.methods.add(bridge);

			ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(w);
			LOGGER.info("PATCHED " + className + " (added the vanilla 8-argument constructor -> " + full.desc + "; CraftWorld creation tolerates non-ServerLevel subclasses)");
			return w.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}

	/** {@code static CraftWorld ankhangbo$createWorld(Level self, NamespacedKey, BiomeProvider, Environment)} : null unless self is a ServerLevel */
	private static MethodNode createWorldMethod(String desc, String craftWorldCtorDesc) {
		MethodNode m = new MethodNode(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_SYNTHETIC, "ankhangbo$createWorld", desc, null, null);
		LabelNode serverLevel = new LabelNode();
		InsnList il = new InsnList();
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new TypeInsnNode(Opcodes.INSTANCEOF, SERVER_LEVEL));
		il.add(new JumpInsnNode(Opcodes.IFNE, serverLevel));
		il.add(new InsnNode(Opcodes.ACONST_NULL));
		il.add(new InsnNode(Opcodes.ARETURN));
		il.add(serverLevel);
		il.add(new FrameNode(Opcodes.F_SAME, 0, null, 0, null));
		il.add(new TypeInsnNode(Opcodes.NEW, CRAFT_WORLD));
		il.add(new InsnNode(Opcodes.DUP));
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new TypeInsnNode(Opcodes.CHECKCAST, SERVER_LEVEL));
		Type[] args = Type.getArgumentTypes(desc);
		for (int i = 1; i < args.length; i++) il.add(new VarInsnNode(Opcodes.ALOAD, i));

		il.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, CRAFT_WORLD, "<init>", craftWorldCtorDesc, false));
		il.add(new InsnNode(Opcodes.ARETURN));
		m.instructions = il;
		return m;
	}

	/** {@code static Identifier ankhangbo$worldId(ResourceKey k)} : {@code (k != null ? k : Level.OVERWORLD).identifier()} */
	private static MethodNode worldIdMethod(String desc, String identifierDesc) {
		MethodNode m = new MethodNode(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_SYNTHETIC, "ankhangbo$worldId", desc, null, null);
		LabelNode present = new LabelNode();
		InsnList il = new InsnList();
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new InsnNode(Opcodes.DUP));
		il.add(new JumpInsnNode(Opcodes.IFNONNULL, present));
		il.add(new InsnNode(Opcodes.POP));
		il.add(new FieldInsnNode(Opcodes.GETSTATIC, LEVEL, "OVERWORLD", "L" + RESOURCE_KEY + ";"));
		il.add(present);
		il.add(new FrameNode(Opcodes.F_SAME1, 0, null, 1, new Object[] { RESOURCE_KEY }));
		il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, RESOURCE_KEY, "identifier", identifierDesc, false));
		il.add(new InsnNode(Opcodes.ARETURN));
		m.instructions = il;
		return m;
	}
}
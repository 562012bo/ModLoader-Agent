package ankhangbo.fabricloader.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Paper/Leaf wrote several {@code Level} methods as {@code ((ServerLevel) this).getChunkSource()...}. Vanilla/Fabric allows mods to
 * subclass {@code Level} directly (Create's SchematicLevel/WrappedLevel, Railways' handcar), and for those the cast throws
 * {@code ClassCastException} (e.g. {@code BlockEntity.setChanged -> Level.hasChunkAt -> Level.getChunkIfLoaded}).
 *
 * <p>For each affected method this inserts, at its very start, {@code if (!(this instanceof ServerLevel)) return <vanilla behaviour>;}.
 * ServerLevel keeps the Paper/Leaf fast path untouched. The vanilla behaviour only uses methods that exist on every Level
 * ({@code getChunk(x, z, status, load)}), so the mod's own chunk source is honoured. {@code setBlock}'s
 * {@code ((ServerLevel) this).hasPhysicsEvent} becomes a call to an added static helper that returns false for non-ServerLevel.</p>
 *
 * <p>Frames: the guard's single branch target gets a hand-written {@code F_SAME} frame; it is placed at the method start where the
 * frame equals the implicit initial one, so the original frames stay valid.</p>
 */
public final class LevelNonServerChunkAccessTransformer implements ClassFileTransformer {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.asm.LevelNonServerChunkAccessTransformer");
	private static final String LEVEL = "net/minecraft/world/level/Level";
	private static final String SERVER_LEVEL = "net/minecraft/server/level/ServerLevel";
	private static final String LEVEL_CHUNK = "net/minecraft/world/level/chunk/LevelChunk";
	private static final String CHUNK_ACCESS = "net/minecraft/world/level/chunk/ChunkAccess";
	private static final String CHUNK_STATUS = "net/minecraft/world/level/chunk/status/ChunkStatus";
	private static final String BLOCK_POS = "net/minecraft/core/BlockPos";
	private static final String BLOCK_STATE = "net/minecraft/world/level/block/state/BlockState";
	private static final String FLUID_STATE = "net/minecraft/world/level/material/FluidState";
	private static final String HAS_PHYSICS = "ankhangbo$hasPhysicsEvent";

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain pd, byte[] buf) {
		if (!LEVEL.equals(className)) return null;

		try {
			ClassNode cn = new ClassNode();
			new ClassReader(buf).accept(cn, 0);

			for (MethodNode m : cn.methods) {
				if (m.name.equals(HAS_PHYSICS)) return null; // already patched
			}

			int guarded = 0;
			boolean physics = false;

			for (MethodNode m : cn.methods.toArray(new MethodNode[0])) {
				InsnList fallback = fallback(m.name, m.desc);

				if (fallback != null && (m.access & Opcodes.ACC_STATIC) == 0) {
					LabelNode server = new LabelNode();
					InsnList guard = new InsnList();
					guard.add(new VarInsnNode(Opcodes.ALOAD, 0));
					guard.add(new TypeInsnNode(Opcodes.INSTANCEOF, SERVER_LEVEL));
					guard.add(new JumpInsnNode(Opcodes.IFNE, server));
					guard.add(fallback);
					guard.add(server);
					guard.add(new FrameNode(Opcodes.F_SAME, 0, null, 0, null));
					m.instructions.insert(guard);
					guarded++;
				}

				// ((ServerLevel) this).hasPhysicsEvent  ->  Level.ankhangbo$hasPhysicsEvent(this)
				if (m.name.equals("setBlock")) {
					for (AbstractInsnNode in : m.instructions.toArray()) {
						if (in instanceof FieldInsnNode f && f.getOpcode() == Opcodes.GETFIELD && f.owner.equals(SERVER_LEVEL) && f.name.equals("hasPhysicsEvent")) {
							AbstractInsnNode prev = f.getPrevious();

							if (prev instanceof TypeInsnNode c && c.getOpcode() == Opcodes.CHECKCAST && c.desc.equals(SERVER_LEVEL)) {
								m.instructions.remove(c);
								m.instructions.set(f, new MethodInsnNode(Opcodes.INVOKESTATIC, LEVEL, HAS_PHYSICS, "(L" + LEVEL + ";)Z", false));
								physics = true;
							}
						}
					}
				}
			}

			if (physics) cn.methods.add(hasPhysicsEventMethod());

			if (guarded == 0 && !physics) {
				LOGGER.warning("Level: none of the ServerLevel-cast methods were found - non-ServerLevel subclasses may still fail");
				return null;
			}

			ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
			cn.accept(w);
			LOGGER.info("PATCHED " + className + " (" + guarded + " chunk-access methods + setBlock now work for non-ServerLevel subclasses)");
			return w.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Failed to patch " + className, t);
			return null;
		}
	}

	/** vanilla behaviour of the given Paper/Leaf method for a Level that is not a ServerLevel, ending in a return; or null if not one of ours */
	private static InsnList fallback(String name, String desc) {
		InsnList il = new InsnList();

		switch (name + desc) {
			// vanilla: (LevelChunk) getChunk(x, z, FULL)
			case "getChunk(II)L" + LEVEL_CHUNK + ";" -> {
				loadChunk(il, true);
				il.add(new TypeInsnNode(Opcodes.CHECKCAST, LEVEL_CHUNK));
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			case "getChunkIfLoadedImmediately(II)L" + CHUNK_ACCESS + ";" -> {
				loadChunk(il, false);
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			case "getChunkIfLoaded(II)L" + LEVEL_CHUNK + ";" -> {
				loadChunk(il, false);
				il.add(new TypeInsnNode(Opcodes.CHECKCAST, LEVEL_CHUNK));
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			case "getChunkAtIfLoadedUnchecked(II)L" + LEVEL_CHUNK + ";" -> {
				il.add(new VarInsnNode(Opcodes.ALOAD, 0));
				il.add(new VarInsnNode(Opcodes.ILOAD, 1));
				il.add(new VarInsnNode(Opcodes.ILOAD, 2));
				il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, LEVEL, "getChunkIfLoaded", "(II)L" + LEVEL_CHUNK + ";", false));
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			// getChunkIfLoaded(BlockPos) -> getChunkIfLoaded(x >> 4, z >> 4)
			case "getChunkIfLoaded(L" + BLOCK_POS + ";)L" + LEVEL_CHUNK + ";" -> {
				il.add(new VarInsnNode(Opcodes.ALOAD, 0));
				il.add(new VarInsnNode(Opcodes.ALOAD, 1));
				il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, BLOCK_POS, "getX", "()I", false));
				il.add(new InsnNode(Opcodes.ICONST_4));
				il.add(new InsnNode(Opcodes.ISHR));
				il.add(new VarInsnNode(Opcodes.ALOAD, 1));
				il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, BLOCK_POS, "getZ", "()I", false));
				il.add(new InsnNode(Opcodes.ICONST_4));
				il.add(new InsnNode(Opcodes.ISHR));
				il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, LEVEL, "getChunkIfLoaded", "(II)L" + LEVEL_CHUNK + ";", false));
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			case "getBlockStateIfLoadedUnchecked(III)L" + BLOCK_STATE + ";" -> {
				il.add(new VarInsnNode(Opcodes.ALOAD, 0));
				newBlockPos(il);
				il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, LEVEL, "getBlockStateIfLoaded", "(L" + BLOCK_POS + ";)L" + BLOCK_STATE + ";", false));
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			case "getFluidStateIfLoadedUnchecked(III)L" + FLUID_STATE + ";" -> {
				il.add(new VarInsnNode(Opcodes.ALOAD, 0));
				newBlockPos(il);
				il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, LEVEL, "getFluidIfLoaded", "(L" + BLOCK_POS + ";)L" + FLUID_STATE + ";", false));
				il.add(new InsnNode(Opcodes.ARETURN));
			}
			default -> {
				return null;
			}
		}

		return il;
	}

	/** pushes {@code this.getChunk(x, z, ChunkStatus.FULL, load)} (ILOAD 1, ILOAD 2 are x, z) */
	private static void loadChunk(InsnList il, boolean load) {
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new VarInsnNode(Opcodes.ILOAD, 1));
		il.add(new VarInsnNode(Opcodes.ILOAD, 2));
		il.add(new FieldInsnNode(Opcodes.GETSTATIC, CHUNK_STATUS, "FULL", "L" + CHUNK_STATUS + ";"));
		il.add(new InsnNode(load ? Opcodes.ICONST_1 : Opcodes.ICONST_0));
		il.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, LEVEL, "getChunk", "(IIL" + CHUNK_STATUS + ";Z)L" + CHUNK_ACCESS + ";", false));
	}

	/** pushes {@code new BlockPos(x, y, z)} from ILOAD 1..3 */
	private static void newBlockPos(InsnList il) {
		il.add(new TypeInsnNode(Opcodes.NEW, BLOCK_POS));
		il.add(new InsnNode(Opcodes.DUP));
		il.add(new VarInsnNode(Opcodes.ILOAD, 1));
		il.add(new VarInsnNode(Opcodes.ILOAD, 2));
		il.add(new VarInsnNode(Opcodes.ILOAD, 3));
		il.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, BLOCK_POS, "<init>", "(III)V", false));
	}

	/** {@code static boolean ankhangbo$hasPhysicsEvent(Level self)} : {@code self instanceof ServerLevel s && s.hasPhysicsEvent} */
	private static MethodNode hasPhysicsEventMethod() {
		MethodNode m = new MethodNode(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_SYNTHETIC, HAS_PHYSICS, "(L" + LEVEL + ";)Z", null, null);
		LabelNode server = new LabelNode();
		InsnList il = new InsnList();
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new TypeInsnNode(Opcodes.INSTANCEOF, SERVER_LEVEL));
		il.add(new JumpInsnNode(Opcodes.IFNE, server));
		il.add(new InsnNode(Opcodes.ICONST_0));
		il.add(new InsnNode(Opcodes.IRETURN));
		il.add(server);
		il.add(new FrameNode(Opcodes.F_SAME, 0, null, 0, null));
		il.add(new VarInsnNode(Opcodes.ALOAD, 0));
		il.add(new TypeInsnNode(Opcodes.CHECKCAST, SERVER_LEVEL));
		il.add(new FieldInsnNode(Opcodes.GETFIELD, SERVER_LEVEL, "hasPhysicsEvent", "Z"));
		il.add(new InsnNode(Opcodes.IRETURN));
		m.instructions = il;
		return m;
	}
}
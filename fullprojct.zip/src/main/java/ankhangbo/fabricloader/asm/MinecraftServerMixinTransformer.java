package ankhangbo.fabricloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.ArrayList;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Fix fabric-lifecycle-events-v1's MinecraftServerMixin:
 *
 * Callback gốc:
 *   @Inject(method = "stopServer", at = @At(value = "INVOKE",
 *       target = "Lnet/minecraft/server/level/ServerLevel;close()V"))
 *   private void onUnloadWorldAtShutdown(CallbackInfo ci, @Local(name = "level") ServerLevel level) {
 *       ServerLevelEvents.UNLOAD.invoker().onLevelUnload((MinecraftServer) (Object) this, level);
 *   }
 *
 * Paper/Leaf đã refactor stopServer() → không còn INVOKE ServerLevel.close()V
 * ở vị trí cũ, local "level" không tồn tại → Mixin fail.
 *
 * Patch thành:
 *   @Inject(method = "stopServer", at = @At("HEAD"))
 *   private void onUnloadWorldAtShutdown(CallbackInfo ci) {
 *       for (ServerLevel level : ((MinecraftServer) (Object) this).getAllLevels()) {
 *           ServerLevelEvents.UNLOAD.invoker().onLevelUnload((MinecraftServer) (Object) this, level);
 *       }
 *   }
 */
public class MinecraftServerMixinTransformer implements ClassFileTransformer {

    private static final String TARGET_CLASS =
        "net/fabricmc/fabric/mixin/event/lifecycle/MinecraftServerMixin";

    @Override
    public byte[] transform(ClassLoader loader, String className,
                            Class<?> classBeingRedefined,
                            ProtectionDomain protectionDomain,
                            byte[] classfileBuffer) throws IllegalClassFormatException {

        if (!TARGET_CLASS.equals(className)) {
            return null;
        }

        System.out.println("[MinecraftServerMixinTransformer] Patching " + className);

        try {
            ClassNode node = new ClassNode();
            new ClassReader(classfileBuffer).accept(node, 0);

            for (MethodNode method : node.methods) {
                if ("onUnloadWorldAtShutdown".equals(method.name)) {
                    fixOnUnloadWorldAtShutdown(method);
                }
            }

            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES) {
                @Override
                protected String getCommonSuperClass(String t1, String t2) {
                    try { return super.getCommonSuperClass(t1, t2); }
                    catch (Throwable t) { return "java/lang/Object"; }
                }
            };
            node.accept(writer);
            return writer.toByteArray();
        } catch (Throwable t) {
            System.err.println("[MinecraftServerMixinTransformer] Failed: " + t);
            t.printStackTrace();
            return null;
        }
    }

    private void fixOnUnloadWorldAtShutdown(MethodNode method) {
        // 1. Sửa @Inject(at = @At("HEAD"))
        if (method.visibleAnnotations != null) {
            for (AnnotationNode ann : method.visibleAnnotations) {
                if (!"Lorg/spongepowered/asm/mixin/injection/Inject;".equals(ann.desc)) continue;
                if (ann.values == null) continue;
                for (int i = 0; i < ann.values.size(); i += 2) {
                    if (!"at".equals(ann.values.get(i))) continue;
                    Object atRaw = ann.values.get(i + 1);
                    if (atRaw instanceof AnnotationNode) {
                        AnnotationNode atNode = (AnnotationNode) atRaw;
                        if (atNode.values == null) atNode.values = new ArrayList<>();
                        atNode.values.clear();
                        atNode.values.add("value");
                        atNode.values.add("HEAD");
                    }
                }
            }
        }

        // 2. Xóa parameter annotations (@Local)
        method.invisibleParameterAnnotations = null;
        method.visibleParameterAnnotations = null;

        // 3. Đổi descriptor: bỏ tham số ServerLevel
        method.desc = "(Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V";

        // 4. Thay body
        InsnList body = new InsnList();

        // this → getAllLevels() → iterator
        body.add(new VarInsnNode(Opcodes.ALOAD, 0));
        body.add(new MethodInsnNode(
            Opcodes.INVOKEVIRTUAL,
            "net/minecraft/server/MinecraftServer",
            "getAllLevels",
            "()Ljava/lang/Iterable;",
            false));
        body.add(new MethodInsnNode(
            Opcodes.INVOKEINTERFACE,
            "java/lang/Iterable",
            "iterator",
            "()Ljava/util/Iterator;",
            true));
        body.add(new VarInsnNode(Opcodes.ASTORE, 1));

        LabelNode loopStart = new LabelNode();
        LabelNode loopEnd = new LabelNode();

        body.add(loopStart);
        body.add(new VarInsnNode(Opcodes.ALOAD, 1));
        body.add(new MethodInsnNode(
            Opcodes.INVOKEINTERFACE,
            "java/util/Iterator",
            "hasNext",
            "()Z",
            true));
        body.add(new JumpInsnNode(Opcodes.IFEQ, loopEnd));

        body.add(new VarInsnNode(Opcodes.ALOAD, 1));
        body.add(new MethodInsnNode(
            Opcodes.INVOKEINTERFACE,
            "java/util/Iterator",
            "next",
            "()Ljava/lang/Object;",
            true));
        body.add(new TypeInsnNode(Opcodes.CHECKCAST, "net/minecraft/server/level/ServerLevel"));
        body.add(new VarInsnNode(Opcodes.ASTORE, 2));

        // ServerLevelEvents.UNLOAD.invoker().onLevelUnload((MinecraftServer)this, level)
        body.add(new FieldInsnNode(
            Opcodes.GETSTATIC,
            "net/fabricmc/fabric/api/event/lifecycle/v1/ServerLevelEvents",
            "UNLOAD",
            "Lnet/fabricmc/fabric/api/event/Event;"));
        body.add(new MethodInsnNode(
            Opcodes.INVOKEVIRTUAL,
            "net/fabricmc/fabric/api/event/Event",
            "invoker",
            "()Ljava/lang/Object;",
            false));
        body.add(new TypeInsnNode(
            Opcodes.CHECKCAST,
            "net/fabricmc/fabric/api/event/lifecycle/v1/ServerLevelEvents$Unload"));
        body.add(new VarInsnNode(Opcodes.ALOAD, 0));
        body.add(new VarInsnNode(Opcodes.ALOAD, 2));
        body.add(new MethodInsnNode(
            Opcodes.INVOKEINTERFACE,
            "net/fabricmc/fabric/api/event/lifecycle/v1/ServerLevelEvents$Unload",
            "onLevelUnload",
            "(Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/server/level/ServerLevel;)V",
            true));

        body.add(new JumpInsnNode(Opcodes.GOTO, loopStart));
        body.add(loopEnd);
        body.add(new InsnNode(Opcodes.RETURN));

        method.instructions = body;
        method.maxStack = 4;
        method.maxLocals = 3;

    }
}
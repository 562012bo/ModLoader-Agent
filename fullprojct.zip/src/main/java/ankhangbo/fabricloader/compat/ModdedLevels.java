package ankhangbo.fabricloader.compat;

import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import java.util.function.Function;

/**
 * Runtime helpers for {@code LevelModdedSubclassCompatTransformer}: default constructor arguments for a {@code Level} subclass a mod
 * creates itself (not a real Bukkit world). JDK types only in the signatures, game types reached reflectively (see NullSafeMaterial).
 */
public final class ModdedLevels {
	private ModdedLevels() { }

	/** world config factory: a mod-made level simply shares the overworld's Paper / Gale world configuration */
	public static Function<Object, Object> configFactory(ClassLoader loader, String kind) {
		return spigotConfig -> {
			try {
				Class<?> serverClass = Class.forName("net.minecraft.server.MinecraftServer", true, loader);
				Object server = serverClass.getMethod("getServer").invoke(null);
				Object overworld = serverClass.getMethod("overworld").invoke(server);
				Method m = overworld.getClass().getMethod(kind.equals("gale") ? "galeConfig" : "paperConfig");
				return m.invoke(overworld);
			} catch (Throwable t) {
				throw new IllegalStateException("cannot get the overworld's " + kind + " config for a mod-created Level", t);
			}
		};
	}

	public static Executor directExecutor() {
		return Runnable::run;
	}
}
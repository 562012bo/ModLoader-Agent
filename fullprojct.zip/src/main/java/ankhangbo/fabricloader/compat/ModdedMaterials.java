package ankhangbo.fabricloader.compat;

import java.lang.instrument.Instrumentation;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Runtime side of {@code ModdedMaterialsTransformer}: creates a Bukkit {@code Material} constant for every modded block/item.
 * Everything is reflective with JDK types in the signatures, because this class lives in the agent jar (parent loader) and cannot see
 * Bukkit/Minecraft types (see NullSafeMaterial's javadoc).
 *
 * <p>Naming: a vanilla key ({@code minecraft:stone}) keeps its constant {@code STONE}; a modded key {@code create:gearbox} becomes
 * {@code CREATE_GEARBOX} with key {@code create:gearbox} (non-alphanumerics become '_'), same scheme as other hybrid servers.
 */
public final class ModdedMaterials {
	private static final Logger LOGGER = Logger.getLogger("ankhangbo.fabricloader.compat.ModdedMaterials");
	private static Instrumentation inst;
	private static boolean done;

	private ModdedMaterials() { }

	/** the agent jar can be loaded twice (system loader + game loader); a JDK-typed entry in System properties is visible to every copy */
	private static final String INST_KEY = "ankhangbo.instrumentation";

	public static void setInstrumentation(Instrumentation i) {
		inst = i;
		System.getProperties().put(INST_KEY, i);
	}

	private static Instrumentation instrumentation() {
		if (inst != null) return inst;
		Object o = System.getProperties().get(INST_KEY);
		return o instanceof Instrumentation ? (Instrumentation) o : null;
	}

	private static String sanitize(String s) {
		StringBuilder sb = new StringBuilder(s.length());

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			sb.append((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ? c : '_');
		}

		return sb.toString();
	}

	private static String call(Object target, String method) throws Exception {
		Method m = target.getClass().getMethod(method);
		m.setAccessible(true);
		return (String) m.invoke(target);
	}

	/** replacement for {@code Identifier.getPath()} in CraftMagicNumbers.<clinit>: the Material constant name for this key (any case) */
	public static String materialPath(Object key) {
		try {
			String ns = call(key, "getNamespace");
			String path = call(key, "getPath");
			return "minecraft".equals(ns) ? path : sanitize(ns + "_" + path);
		} catch (Throwable t) {
			throw new IllegalStateException("cannot read resource key " + key, t);
		}
	}

	public static synchronized void registerAll(ClassLoader loader) {
		if (done) return;
		done = true;

		try {
			Class<?> registries = Class.forName("net.minecraft.core.registries.BuiltInRegistries", true, loader);
			Class<?> materialClass = Class.forName("org.bukkit.Material", true, loader);
			Method add = materialClass.getMethod("ankhangbo$add", String.class, String.class, String.class);
			Method get = materialClass.getMethod("getMaterial", String.class);
			Method values = materialClass.getMethod("values");
			int before = ((Object[]) values.invoke(null)).length;
			int added = 0;
			Set<String> namespaces = new TreeSet<>();

			for (String field : new String[] {"BLOCK", "ITEM"}) {
				Object registry = registries.getField(field).get(null);
				Method keySet = registry.getClass().getMethod("keySet");
				keySet.setAccessible(true);

				for (Object key : (Set<?>) keySet.invoke(registry)) {
					String ns = call(key, "getNamespace");
					if ("minecraft".equals(ns)) continue;

					String path = call(key, "getPath");
					String name = sanitize(ns + "_" + path).toUpperCase(Locale.ROOT);

					if (get.invoke(null, name) != null) continue; // BLOCK and ITEM share a key, or already added

					add.invoke(null, name, ns, path);
					namespaces.add(ns);
					added++;
				}
			}

			boolean ordered = added > 0 && placeBeforeLegacy(materialClass, values, before);
			resetEnumCaches(materialClass);
			boolean registry = added > 0 && refreshMaterialRegistry(loader, materialClass, values);
			LOGGER.info("Added " + added + " Bukkit Material constants for modded blocks/items (namespaces: " + namespaces + ")"
					+ (added > 0 ? (ordered ? ", placed before the LEGACY_ constants" : ", WARNING: left after the LEGACY_ constants")
					+ (registry ? ", Registry.MATERIAL refreshed" : ", WARNING: Registry.MATERIAL not refreshed") : ""));
		} catch (Throwable t) {
			LOGGER.log(Level.SEVERE, "Could not create Bukkit Materials for modded blocks/items - plugins will see null materials", t);
		}
	}

	private static boolean javaLangOpen;

	/** opens java.lang to this class' module (needs the agent's Instrumentation); returns false if that is not possible */
	private static boolean openJavaLang() {
		if (javaLangOpen) return true;
		Instrumentation i = instrumentation();

		try {
			Module base = Object.class.getModule();
			Module me = ModdedMaterials.class.getModule();

			if (i != null) i.redefineModule(base, Set.of(), Map.of(), Map.of("java.lang", Set.of(me)), Set.of(), Map.of());
			javaLangOpen = base.isOpen("java.lang", me);
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Could not open java.lang to the agent", t);
		}

		if (!javaLangOpen) LOGGER.warning("java.lang is not open to the agent (Instrumentation " + (i == null ? "missing" : "present") + ")");
		return javaLangOpen;
	}

	/**
	 * Paper's plugin rewriting (Commodore) turns {@code Material.values()} into {@code CraftLegacy.modern_values()} =
	 * {@code values[0 .. LEGACY_AIR.ordinal())} and {@code ordinal()} into {@code modern_ordinal}, and sizes every plugin's
	 * {@code switch}/EnumMap tables from that. So the new constants must sit BEFORE the LEGACY_ constants (which are the tail of the
	 * enum); otherwise ordinals of modded materials are outside modern_values() (WorldGuard: "Index 4825 out of bounds for length
	 * 1691"). Re-numbers the shifted legacy constants (Enum.ordinal) and rewrites {@code $VALUES}.
	 */
	private static boolean placeBeforeLegacy(Class<?> materialClass, Method values, int before) {
		try {
			if (!openJavaLang()) return false;

			Object[] all = (Object[]) values.invoke(null);
			int legacyAt = -1;

			for (int i = 0; i < before; i++) {
				if (((Enum<?>) all[i]).name().equals("LEGACY_AIR")) { legacyAt = i; break; }
			}

			if (legacyAt < 0) return false;

			Object[] ordered = all.clone();
			int n = 0;

			for (int i = 0; i < legacyAt; i++) ordered[n++] = all[i];
			for (int i = before; i < all.length; i++) ordered[n++] = all[i];
			for (int i = legacyAt; i < before; i++) ordered[n++] = all[i];

			java.lang.reflect.Field ord = Enum.class.getDeclaredField("ordinal");
			ord.setAccessible(true);

			for (int i = 0; i < ordered.length; i++) ord.setInt(ordered[i], i);

			java.lang.reflect.Field vals = materialClass.getDeclaredField("$VALUES");
			vals.setAccessible(true);
			vals.set(null, ordered);
			return true;
		} catch (Throwable t) {
			LOGGER.log(Level.SEVERE, "Could not place the modded Materials before the LEGACY_ ones - plugins that switch on Material will fail", t);
			return false;
		}
	}

	/**
	 * {@code Registry.MATERIAL} is a SimpleRegistry whose immutable map is built from {@code Material.class.getEnumConstants()} when the
	 * Registry interface is first initialised - normally before this runs - so WorldEdit/CoreProtect ({@code Registry.MATERIAL.get(key)})
	 * would not find modded materials. Rebuild that map (key -> Material, non-legacy only, same predicate as Registry.MATERIAL).
	 */
	private static boolean refreshMaterialRegistry(ClassLoader loader, Class<?> materialClass, Method values) {
		try {
			Object registry = Class.forName("org.bukkit.Registry", true, loader).getField("MATERIAL").get(null);
			Method getKey = materialClass.getMethod("getKey");
			Method isLegacy = materialClass.getMethod("isLegacy");
			Map<Object, Object> map = new java.util.LinkedHashMap<>();

			for (Object m : (Object[]) values.invoke(null)) {
				if (!(Boolean) isLegacy.invoke(m)) map.put(getKey.invoke(m), m);
			}

			for (Class<?> c = registry.getClass(); c != null; c = c.getSuperclass()) {
				try {
					java.lang.reflect.Field f = c.getDeclaredField("map");
					f.setAccessible(true);
					f.set(registry, java.util.Collections.unmodifiableMap(map));
					return true;
				} catch (NoSuchFieldException ignored) {
					// try the superclass
				}
			}

			LOGGER.warning("Registry.MATERIAL has no 'map' field (" + registry.getClass() + ")");
			return false;
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Could not refresh Registry.MATERIAL", t);
			return false;
		}
	}

	/** Class#enumConstants / enumConstantDirectory may already be cached with the old constant list; clear them (best effort) */
	private static void resetEnumCaches(Class<?> enumClass) {
		try {
			if (!openJavaLang()) return;
			MethodHandles.Lookup l = MethodHandles.privateLookupIn(Class.class, MethodHandles.lookup());

			for (String f : new String[] {"enumConstants", "enumConstantDirectory"}) {
				try {
					VarHandle vh = l.findVarHandle(Class.class, f, f.equals("enumConstants") ? Object[].class : Map.class);
					vh.set(enumClass, null);
				} catch (NoSuchFieldException e) {
					LOGGER.fine("Class." + f + " not present on this JDK");
				}
			}
		} catch (Throwable t) {
			LOGGER.log(Level.WARNING, "Could not reset Material's cached enum constants (fine unless something used EnumMap(Material) before this point)", t);
		}
	}
}